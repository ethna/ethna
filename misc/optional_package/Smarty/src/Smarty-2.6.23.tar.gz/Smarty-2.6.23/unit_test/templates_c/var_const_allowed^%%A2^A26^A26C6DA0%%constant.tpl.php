<?php /* Smarty version 2.6.23-dev, created on 2009-04-30 16:16:54
         compiled from constant.tpl */ ?>
<?php echo @TEST_CONSTANT; ?>
