<?php /* Smarty version 2.6.23-dev, created on 2009-04-30 16:16:54
         compiled from assign_var.tpl */ ?>
<?php echo $this->_tpl_vars['foo']; ?>
