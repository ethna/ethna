<?php $_config_vars = array (
  'foo' => 'bar',
); ?>